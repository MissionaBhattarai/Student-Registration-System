import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ViewAttendance extends JFrame {
    private JTable table;
    private JButton newButton;

    public ViewAttendance() {
        String[] columnNames = {"id", "Student Name", "date"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        table = new JTable(model);

        JScrollPane scrollPane = new JScrollPane(table);

        newButton = new JButton("Back");
        
         newButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                   setVisible(false);
                    new Home().setVisible(true);
            }
        });
        
     

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.add(newButton);

        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        tablePanel.add(buttonPanel, BorderLayout.SOUTH);

        add(tablePanel);

        setTitle("Student Table");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);

        displayStudentData();
    }

    private void displayStudentData() {
        try {
             Class.forName("com.mysql.cj.jdbc.Driver");  
        Connection connection=DriverManager.getConnection(  
    "jdbc:mysql://localhost:3306/jmc","root","sonam1234");
        
            String selectQuery = "SELECT attendance.id, student.first_name AS sname, date FROM attendance JOIN student ON(StudentID) ";

            PreparedStatement preparedStatement = connection.prepareStatement(selectQuery);

            ResultSet resultSet = preparedStatement.executeQuery();

            DefaultTableModel model = (DefaultTableModel) table.getModel();
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String sname = resultSet.getString("sname");
                String date = resultSet.getString("date");
             

                Object[] rowData = {id, sname, date};
                model.addRow(rowData);
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {

    }
}
