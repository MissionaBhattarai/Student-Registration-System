import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class CheckboxGenerator extends JFrame {

    private List<JCheckBox> checkboxes;
    private List<Integer>checkboxID;

    public CheckboxGenerator() {
        setTitle("Do attendance");
                setSize(600, 600);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new FlowLayout());
        checkboxes = new ArrayList<>();
        checkboxID = new ArrayList<>();

        try {
           Class.forName("com.mysql.cj.jdbc.Driver");  
        Connection connection=DriverManager.getConnection(  
    "jdbc:mysql://localhost:3306/jmc","root","sonam1234");
        
            String selectQuery = "SELECT id, first_name, last_name, phone, email, city FROM Student";

            PreparedStatement preparedStatement = connection.prepareStatement(selectQuery);

            ResultSet resultSet = preparedStatement.executeQuery();
            
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String firstName = resultSet.getString("first_name");
                String lastName = resultSet.getString("last_name");
                
                String fullName = firstName + lastName;
                JCheckBox checkBox = new JCheckBox(fullName);
                add(checkBox);
                checkboxes.add(checkBox);
                checkboxID.add(id);
                
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        
 


        JButton printButton = new JButton("Done");
        printButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                printSelectedCheckboxes();
            }
        });
        add(printButton);

        pack();
        setVisible(true);
    }


    public void printSelectedCheckboxes() {
        System.out.println("Selected Checkboxes:");
        for (JCheckBox checkBox : checkboxes) {
            int index = checkboxes.indexOf(checkBox);
            int id = checkboxID.get(index);
            String strid = Integer.toString(id);
            
            if (checkBox.isSelected()) {
                System.out.println(checkBox.getText());
                
               try {
                Class.forName("com.mysql.cj.jdbc.Driver");  
                Connection connection=DriverManager.getConnection(  
                        "jdbc:mysql://localhost:3306/jmc","root","sonam1234");
        
                String insertQuery = "INSERT INTO Attendance (StudentID) VALUES (?)";    // Step 4: Create a prepared statement
                PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
                preparedStatement.setString(1,strid);


                preparedStatement.executeUpdate();
                preparedStatement.close();
                connection.close();



               }
               catch (Exception e) {
                   e.printStackTrace();
               }
               
                  setVisible(false);
            new Home().setVisible(true);    }                                        

        
        
                
                
                
                
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CheckboxGenerator());
    }
}
